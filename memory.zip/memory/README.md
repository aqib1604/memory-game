#Information


Curently We have developed card game according to your requirement with static Images. We haven't used dackofcards API because of less time. App is woring fine with react Js. As well as we are remaining with SAve score cards functionality. As  you will see there is a count of score while playing and we can save this easily through node if we have a more time.

